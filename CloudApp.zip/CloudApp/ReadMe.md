User Story:
As a CloudApp consumer, I want the ability to create accounts and login, so that I can have a personalized user experience.


Test Plan:

    Scenario #1: Account Creation

        Email Address:
            1. Email field cannot be blank (manual test)
            2. Email field must contain @ sign (manual test)

        Password:
            1. Password field cannot be blank (manual test)
            2. Password field must be at least 8 characters
            3. Password field must contain uppercase letters
            4. Password field must contain at least one number
  
    Scenario #2: Account Login

        Email Address:
            1. Email field cannot be blank (manual test)
            2. Failed login attempt - Email/Password combination is incorrect

        Password:
            1. Password field cannot be blank (manual test)

    Scenario #3: Successful Login
        
        Avatar:
            1. Update avatar
            2. Upload a picture bigger than 500x500 (manual test)

Follow-up Questions to Product Team:
    1. Is there a character limit for the Email/Password fields?
    2. Should the Sign Up and Sign In buttons be disabled until the Email/Password fields are filled out?

Future Stories:
    1. "Sign Up with Google" functionality
    2. "Sign Up with Apple" functionality
    3. "Sign Up with SSO" functionality
    4. "Forgot password?" functionality