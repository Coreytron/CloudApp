const { defineConfig } = require("cypress");

module.exports = defineConfig({
  chromeWebSecurity: false,
  e2e: {
    baseUrl: "https://getcloudapp.com/",
    viewportWidth: 1280,
    viewportHeight: 720,
    defaultCommandTimeout: 15000
  },

  env: {
    loginPassword: 'Test1234!'
  }
});
