// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

import 'cypress-file-upload';

Cypress.Commands.add('getByClass', (elementClass) => {
    cy.get(`[class="${elementClass}"]`);
});

Cypress.Commands.add('getByDataTestId', (elementDataTestId) => {
    cy.get(`[data-testid="${elementDataTestId}"]`);
});

Cypress.Commands.add('getByHref', (href) => {
    cy.get(`[href="${href}"]`);
});

Cypress.Commands.add('generateEmailAddress', (emailAddress) => {
    const randomInt = Math.floor(Math.random() * 10000);
    return `${emailAddress}${randomInt}@testuser.com`
});

Cypress.Commands.add('clickLogInLink', () => {
    cy.getByClass('menu-top-nav-desktop-container').contains('Log in').click();
});

Cypress.Commands.add('enterLoginCredentials', (emailAddress, password) => {
    cy.get('form').find('input[type="email"]').type(emailAddress);
    cy.get('form').find('input[type="password"]').type(password);
    cy.get('form').find('input[type="submit"]').click();
});
