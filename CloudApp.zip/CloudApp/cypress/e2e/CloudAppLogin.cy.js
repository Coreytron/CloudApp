/*
TO REVIEWER: 
  1. I have created a user story and test plan for this assignment. They are located in the ReadMe.md file in the root directory of this project. 
  2. I also added my own custom commands to the commands.js file and edited Cypress defaults and env variables within e2e.js.

NOTE: This was created with Cypress 10.7.0, so there are a few differences compared to earlier versions.

ASSUMPTIONS:
  1. Navigation of page prior to login is handled by a different test class
  2. Navigation of the account dropdown menu is handled by a different test class
*/

let emailAddress;
const loginUrl = '/login';
const pwAlert = 'flash alert alert-danger';
const pwFailedValidation = 'Validation failed: Password must be at least 8 characters long, contain uppercase and lowercase letters and a number.';
const signUpUrl = '/signup';

describe('CloudApp Account Creation and Login: Happy Path and Failure Scenarios', () => {

  before(() => {
    cy.generateEmailAddress('coreytest').then((email) => {
      emailAddress = email;
    });
  });

  describe('Account Creation Test Scenarios', () => {
  
    beforeEach(() => {
      cy.visit(signUpUrl);
    });
    
    it('Validates Password field must be at least 8 characters', () => {
      cy.enterLoginCredentials(emailAddress, 'Test123');
      cy.getByClass(pwAlert).should('contain', pwFailedValidation);
    });
    
    it('Validates Password field must contain an uppercase character', () => {
      cy.enterLoginCredentials(emailAddress, 'testtest123');
      cy.getByClass(pwAlert).should('contain', pwFailedValidation);
    });

    it('Validates Password field must contain a lowercase character', () => {
      cy.enterLoginCredentials(emailAddress, 'TESTTEST123');
      cy.getByClass(pwAlert).should('contain', pwFailedValidation);
    });

    it('Validates Password field must contain a number', () => {
      cy.enterLoginCredentials(emailAddress, 'Testtesttest');
      cy.getByClass(pwAlert).should('contain', pwFailedValidation);
    });

    //Subsequent tests are dependent on this test running (alternate route could be setting up a different account in the before hook so each test can be run independently)
    it('Validates a new account can be created', () => {
      cy.enterLoginCredentials(emailAddress, Cypress.env('loginPassword'));
      cy.url().should('not.contain', signUpUrl);
      cy.getByClass('toast-body').should('contain', 'Account created successfully');
    });
  });
  
  describe('Login Test Scenarios', () => {
  
    beforeEach(() => {
      cy.visit(loginUrl);
    });
    
    it('Validates failed login attempt with incorrect Email/Password combination', () => {
      cy.enterLoginCredentials(emailAddress, 'BadPasswordIsBad');
      cy.url().should('contain', loginUrl);
      cy.getByClass('alert alert-danger').should('contain', 'Invalid email / password combination');
    });
    
    it('Validates logging in with an existing account', () => {
      cy.enterLoginCredentials(emailAddress, Cypress.env('loginPassword')); //TODO: Setup a new Cypress command for logging in through the API for efficiency in future tests
      cy.url().should('not.contain', loginUrl);
      cy.getByClass('dropdown-item').first().should('contain', emailAddress);
      cy.getByHref('/logout').click({ force: true }); //Resetting the Cypress state before the next test runs to avoid flakiness around opening a new instance and it thinking a user is already logged in
    });
  
    it('Validates logging out for a logged in account', () => {
      cy.enterLoginCredentials(emailAddress, Cypress.env('loginPassword'));
      cy.getByHref('/logout').click({ force: true });
      cy.url().should('contain', loginUrl);
      cy.getByClass('alert alert-success').should('contain', 'Successfully Logged Out');
    });
  });

  describe('Successful Login Scenarios', () => {

    beforeEach(() => {
      cy.visit(loginUrl);
    });
    
    it('Validates an avatar can be added to account', () => {
      const shockwaveImage = 'images/ShockwaveSalute.jpg';
      cy.enterLoginCredentials(emailAddress, Cypress.env('loginPassword'));
      cy.getByDataTestId('dropdown-link-settings').click({ force: true });
      cy.get('[id="user_avatar"]').attachFile(shockwaveImage);
      cy.getByDataTestId('onboarding-submit-about-you-form').click();
      cy.getByClass('flash alert alert-success').should('contain', 'Account updated successfully');
    });
  });
});
